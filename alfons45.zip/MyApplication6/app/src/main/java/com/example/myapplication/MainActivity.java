package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import android.app.Activity;

public class MainActivity extends AppCompatActivity {

    private TextView resultTextView;
    private EditText number_field_1, number_field_2;
    private Button button;
    private Button button3;

    static final String AGE_KEY = "AGE";
    static final String ACCESS_MESSAGE="ACCESS_MESSAGE";

    ActivityResultLauncher<Intent> mStartForResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {

                    TextView textView = findViewById(R.id.textView);
                    if(result.getResultCode() == Activity.RESULT_OK){
                        Intent intent = result.getData();
                        String accessMessage = intent.getStringExtra(ACCESS_MESSAGE);
                        textView.setText(accessMessage);
                    }
                    else{
                        textView.setText("Ошибка доступа");
                    }
                }
            });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClick(View view) {
        // получаем введенный возраст
        EditText ageBox = findViewById(R.id.age);
        String age = ageBox.getText().toString();

        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtra(AGE_KEY, age);

        mStartForResult.launch(intent);



            resultTextView = findViewById(R.id.resultTextView);
            number_field_1 = findViewById(R.id.number_field_1);
            number_field_2 = findViewById(R.id.number_field_2);
            button = (Button) findViewById(R.id.button);
            button3 = (Button) findViewById(R.id.knopka);

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    float num1 = Float.parseFloat(number_field_1.getText().toString());
                    float num2 = Float.parseFloat(number_field_2.getText().toString());
                    float res = num1 + num2;
                    resultTextView.setText(String.valueOf(res));
                }
            });

            }
        }









